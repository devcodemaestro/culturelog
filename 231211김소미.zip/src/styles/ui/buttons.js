import { css } from "@emotion/react";

export const SubmitBtn = css``;
