import React from "react";

const UpcomingLog = () => {
  return <div>UpcomingLog</div>;
};

export default UpcomingLog;
