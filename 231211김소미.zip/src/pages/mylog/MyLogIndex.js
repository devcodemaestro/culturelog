import React from "react";
import { Outlet } from "react-router";

const MyLogIndex = () => {
  return (
    <>
      <Outlet></Outlet>
    </>
  );
};

export default MyLogIndex;
