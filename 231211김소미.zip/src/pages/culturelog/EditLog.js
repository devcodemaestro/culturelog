import React from "react";

const EditLog = () => {
  return <div>EditLog</div>;
};

export default EditLog;
