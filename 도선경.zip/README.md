# Cluture Log : 문화생활 기록 서비스

## 1. 프로젝트 정보

- [Notion](https://)
- [Figma](https://)
- 기간 :

## 2. 활용 모듈

- emotion
- sass
- ant
- eslint
- prettier
- react-router
- react-router-dom
- axios

## 3. 프로젝트 후기
