import React, { useEffect, useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { LogListWrap, LogTotal } from "../../styles/ui/logliststyle";
import LogTab from "../../components/loglist/LogTab";
import LogListItem from "../../components/loglist/LogListItem";
import { getMedia } from "../../api/culutrelog_api";
import PastLogList from "../../components/loglist/PastLogList";

const initPastLog = [
  {
    imedia: 0,
    title: "",
    date: "",
    pic: "",
    sawInfo: {
      star: 0,
      comment: "",
    },
  },
];

const PastLog = () => {
  const [loglist, setLogList] = useState(initPastLog);

  useEffect(() => {
    getMedia(setLogList, 1, 1);
  }, []);

  const totalLogList = loglist.length;
  return (
    <>
      <Header sub={true}>My Log</Header>
      <LogTab on="past"></LogTab>
      <PastLogList></PastLogList>
      <Footer />
    </>
  );
};

export default PastLog;
