import React, { useEffect, useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { LogListWrap } from "../../styles/ui/logliststyle";
import LogTab from "../../components/loglist/LogTab";
import LogListItem from "../../components/loglist/LogListItem";
import { getMedia } from "../../api/culutrelog_api";
import UpcomingLogList from "../../components/loglist/UpcomingLogList";

const initUpcomingLog = [
  {
    imedia: 0,
    title: "",
    date: "",
    pic: "",
    sawInfo: {
      star: 0,
      comment: "",
    },
  },
];

const UpcomingLog = () => {
  const [loglist, setLogList] = useState(initUpcomingLog);
  useEffect(() => {
    getMedia(setLogList, 1, 0);
  }, []);
  return (
    <>
      <Header sub={true}>My Log</Header>
      <LogTab on="upcoming"></LogTab>
      <UpcomingLogList />
      <Footer />
    </>
  );
};
export default UpcomingLog;
