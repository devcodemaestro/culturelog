import React from "react";
import { LogTabBt } from "../../styles/ui/logtabstyle";
import { useNavigate } from "react-router-dom";

const LogTab = props => {
  const navigate = useNavigate();
  return (
    <>
      <LogTabBt>
        <button className={props.on} onClick={props.tabClickOn}>
          볼 거예요
        </button>
        <button className={props.on} onClick={props.tabClickOn}>
          봤어요
        </button>
      </LogTabBt>
    </>
  );
};

export default LogTab;
